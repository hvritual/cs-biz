from pathlib import Path
import hashlib,json,datetime,subprocess,importlib.util,sys
sys.dont_write_bytecode=True
root=Path('/workspace/scratch/0fc9dd84ab02/w06-forward-saas');repo=Path('/workspace/scratch/0fc9dd84ab02/cs-biz')
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(p):return {'path':str(p.relative_to(root)),'sha256':h(p)}
archive=root/'revisions/r001';archive.mkdir(parents=True,exist_ok=True)
for name in ['goal.json','assessment.json','architecture.json','sources.json','write_records.py']:(archive/name).write_bytes((root/name).read_bytes())
current=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
files=[]
for manifest in ['baseline.json','workflow-and-extra-source-manifest.json']:
 data=json.loads((root/'raw'/manifest).read_text())
 for item in data['files']:
  rel=item.get('source_path',item.get('path'));snap=root/'raw/local'/rel;live=repo/rel
  files.append({'path':rel,'snapshot_sha256':h(snap),'current_sha256':h(live),'same_bytes':h(snap)==h(live)})
changed=[x for x in files if not x['same_bytes']]
allowed={'.agents/skills/intent-to-outcome-closure/scripts/check_goal.py','.agents/skills/intent-to-outcome-closure/references/goal-coordination.md'}
assert {x['path'] for x in changed}==allowed,changed
for x in changed:
 target=root/'raw/revision-r002'/x['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((repo/x['path']).read_bytes());x['new_snapshot']=str(target.relative_to(root))
for p in list((root/'raw/local').rglob('__pycache__')):
 for f in p.glob('*.pyc'):f.unlink()
 p.rmdir()
write(root/'raw/source-reconciliation.json',{'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'initial_head':'4d5dd75500de601cbadd41ade18c2459c72c23b5','current_local_candidate':current,'canonical_github_main':'4d5dd75500de601cbadd41ade18c2459c72c23b5','files':files,'assessment':'Business/architecture/app source bytes unchanged. Current owning goal coordinator reference/checker changed; read diff and reconcile routing naming ROUTE_SOFTWARE. r001 initial contract and failed check retained, no Human acceptance or software proof imported. Task-generated Python bytecode was excluded from source evidence.'})
g=json.loads((root/'goal.json').read_text());a=json.loads((root/'assessment.json').read_text());t=json.loads((root/'architecture.json').read_text())
g['revision']='r002';g['baseline_sha']=current;g['budget']['attempts_without_progress']=1
for source in g['sources']:
 if source['channel']=='local':source['version']='local candidate '+current+'; byte-identical to task initial source snapshot; independently reconciled from main '+ '4d5dd75500de601cbadd41ade18c2459c72c23b5'
g['sources'].append({'id':'G-MAIN-RECHECK','channel':'github','locator':'https://api.github.com/repos/hvritual/cs-biz/branches/main','version':'independent re-read 2026-10-16; canonical main 4d5dd75500de601cbadd41ade18c2459c72c23b5','artifact_ref':ref(root/'raw/github-main-recheck.txt')})
for name,source_id in [('references/goal-coordination.md','L-CURRENT-COORDINATION'),('scripts/check_goal.py','L-CURRENT-CHECKER')]:
 rel='.agents/skills/intent-to-outcome-closure/'+name;file=root/'raw/revision-r002'/rel
 g['sources'].append({'id':source_id,'channel':'local','locator':str(repo/rel),'version':'local candidate '+current+'; exact current source snapshot; not canonical main','artifact_ref':ref(file)})
g['searches'][0]['source_ids']+=['L-CURRENT-COORDINATION','L-CURRENT-CHECKER'];g['searches'][0]['reason']+=' Local baseline advanced during analysis; exact source reconciliation shows product/app bytes unchanged, while current routing/checker source was re-read and rebound in r002.'
g['searches'][1]['source_ids'].append('G-MAIN-RECHECK')
current_checker=repo/'.agents/skills/intent-to-outcome-closure/scripts/check_goal.py'
spec=importlib.util.spec_from_file_location('goal_checker_current',current_checker);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
basis=module.basis(g);a['basis_sha256']=basis;t['basis_sha256']=basis
write(root/'assessment.json',a);g['records']['assessment']=ref(root/'assessment.json');t['assessment_sha256']=g['records']['assessment']['sha256']
t['current_state'][0]='初始观察本地 HEAD 与 GitHub main 均 4d5dd75500de601cbadd41ade18c2459c72c23b5。分析期间本地推进为候选 '+current+'；再次独立回读 GitHub canonical main 仍为 4d5dd75500de601cbadd41ade18c2459c72c23b5。任务所读业务/应用源码字节全部相同；当前协调引用与 checker 已另存并复读。未将本地候选记为 main。'
write(root/'architecture.json',t);g['records']['architecture']=ref(root/'architecture.json');write(root/'goal.json',g)
write(root/'sources.json',{'as_of':datetime.datetime.now(datetime.timezone.utc).isoformat(),'local_candidate':current,'canonical_github_main':'4d5dd75500de601cbadd41ade18c2459c72c23b5','reconciliation':'raw/source-reconciliation.json','sources':g['sources']})
print(json.dumps({'revision':g['revision'],'baseline_sha':current,'basis_sha256':basis,'source_count':len(g['sources']),'checker_sha256':h(current_checker),'changed_inputs':[x['path'] for x in changed]},ensure_ascii=False))
