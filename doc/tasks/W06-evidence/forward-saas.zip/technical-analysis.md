# 实际技术状况与技术路线 · r003 待审

推荐保留当前 Yunka/PB/Consumer 与现有 Console，在不产生第二套权限或执行权威的前提下，补齐真实身份/Access、模块可用性、Domain 持久化和可恢复结果。现状足以作为开发基础；不足以认定真实 SaaS、完整安全隔离或生产就绪。

## 版本和证据边界

- 初始本地 HEAD 与独立 GitHub main 回读均为 `4d5dd75500de601cbadd41ade18c2459c72c23b5`。
- 分析期间本地推进为候选 `aec53bddd7818e8a554c01902342593f894c4dc9`；再次独立回读 GitHub main 仍为 `4d5dd755…`。候选不视为 canonical main。
- 已读业务/应用源码逐文件重新比对，字节全部相同；仅当前协调引用和 checker 与最初快照不同，已读取差异、另存当前版本并更新 r002。记录见 [source-reconciliation](raw/source-reconciliation.json)。原 r001 和基线漂移失败保留。
- [sources.json](sources.json) 绑定 34 个实际来源与精确字节摘要。工作树源码不是只靠 HEAD 认证；初始与当前工作流快照分开。
- 没有读取测试、W06 validation/evidence、其他 Agent 输出或此前对话；没有修改源码、生成、安装依赖、创建外部事项或部署。

## 当前消费者实际做了什么

| 边界 | 直接观察 | 结论与限制 |
| --- | --- | --- |
| Console 数据与身份 | `workspace.ts` 直接导入 `api/mock/service`；service 通过 localStorage 保存实体、sessionStorage 选择账户，`selectUser` 不校验凭据 | 有前端交互与上下文逻辑，尚无真实身份/服务端权限证明；页面完成不能视为能力完成 |
| 前端上下文 | RequestEpoch/generation、受控动态路由、标签页租户缓存与失效处理存在 | 可复用语义与组件；真实 HTTP、CSRF、跨实例撤权和服务端状态需要新增接入与实测 |
| Authz V2 | `CurrentAuthority` 定义当前 Membership/Grant seam；`Authorize` 匹配租户及动作范围，资源校验/查询范围分开 | 存在可复用授权内核；不能据接口存在推断已有真实 IAM 存储。列表/导出仓储必须自身强制 Tenant AND Scope |
| canonical PB | `runtime.proto` 只有公共只读 `runtime.inspect`，无事务/幂等策略 | 当前无可写业务 Operation；不另建竞争 OpenAPI schema 或手改生成物 |
| 实际运行组装 | probe 限制 loopback，只注册生成 gRPC；非公共 permission 查询 deny-all；返回技术状态 | 此探针不能作为业务授权入口。生成 REST 空壳、OpenAPI 或 TS client 不等于真实 HTTP/前端接入 |
| 业务持久化 | 生产 Go 文件清单主要是 probe/assembly/authz/telemetry；当前 module 无业务仓储或迁移 | 未找到真实 Account/Tenant/Membership/Grant/业务资源的持久消费者；MySQL 间接依赖不能替代采用决定 |
| 观测 | 源码沿 Yunka Provider 导出技术 span，文档限定本地 Collector/Jaeger | 本轮未运行探针/查询；不将文档历史资格或外部能力当本次浏览器业务链证据 |

本次执行观察：PATH 中 `go`、`docker`、`yunka` 查询均 exit 1；Node 为 `v24.19.0`，全局 pnpm 为 `11.25.0`，项目声明 `pnpm@10.33.4`。这只说明当前可见工具入口，不能推断机器其他位置没有工具。未运行 build、单测、端到端、浏览器或真实 DB/API；原始命令见 [inspection-commands.json](raw/inspection-commands.json)。

当前七个 PR `#2/#7/#8/#18/#21/#23/#25` 仍 open，其中 `#8` 基于 `#7` 分支、`#25` 基于 `#21` 分支；均不作为 main 能力。F2 [#13](https://github.com/hvritual/cs-biz/issues/13) 和 F3 [#14](https://github.com/hvritual/cs-biz/issues/14) 真实回读仍写有规划而未实现，不能从候选标题推断交付。

## Yunka 固定输入与当前资格

| 输入 | 实际锁/外部读取 | 本轮可证明与未证明 |
| --- | --- | --- |
| 四个 Go 模块 | `framework/gateway/pkg` 的 `v0.1.1-0.20261015114616-bc7c0e1dd6b4`，`infras` 的 `v0.0.0-20261015114616-bc7c0e1dd6b4` | go.mod 与 consumer-lock 指向 SDK `bc7c0e1dd6b4e815951130c7acfbf60371445453`；未下载/重验所有 Go module 字节 |
| CLI producer | `3e46ec4d51b9c31bd9f687bb4f773b314cd57451`，不同于 SDK commit | 区分生产 CLI 与 SDK 身份，不能合成一个 commit 字段 |
| 固定制品 | run `38734324861`，artifact `11971414833`；列表返回 `expired=false`，到期 `2026-11-14T12:26:20Z` | API metadata 的 zip digest 与本地 `5aece1d69b7708dfede53406d634dbc03aafb234ebe71d3df7f8a911b4ae69fd` 相符；没有下载、计算 archive/tar/manifest 字节或运行验证 |
| 工具 | Go `1.26.9`/language `1.26.0`、protoc `3.21.12`、Go plugin `1.36.11`/gRPC plugin `1.6.2`、linux/amd64、固定安装根 | 是消费者固定要求；不是本环境工具通过记录。到期、权限、摘要或工具不符须按原规则阻断 |

上游固定 README 可读，支持单一 typed Operation/执行与应用生命周期的分析；其自身框架能力不代表已在 cs-biz 完整组装。现有 F0/F1 设计及消费者治理继续保留，不重新创建第二 Runtime、拷贝 SDK 或绕过生成所有权。

## 成熟方案比较与反证

| 参考 | 本轮实际访问 | 可借鉴 | 适配与反证 |
| --- | --- | --- | --- |
| ABP 多租户/租户管理 | 官方 latest 文档、发布 `10.7.0`（2026-10-06），根 `LICENSE.md` | 租户存储、管理与商业 SaaS 分开；共享库/独库/混合模式分层比较 | .NET 体系并非 Go 组件。官方租户模块文档声称模块源为 MIT，但实际发布根许可为 LGPL v3；不能把模块声明套给整个发行物；商业 SaaS 模块另有分发边界。这里只借鉴模式，直接代码复用须核对精确文件/包 |
| Keycloak Organizations | `26.8.1` 官方管理指南、同版 Apache 2.0 许可及发布（2026-10-13） | 认证、身份联邦、组织成员加入和 OIDC 身份入口 | 组织停用对 managed/unmanaged 成员影响不同；不能把 Organization claim 当当前 SaaS Membership 或数据库隔离。需 BFF/Access 映射与撤销实测；本项目未接入 |
| PostgreSQL 行安全 | 官方 PostgreSQL 17 文档；参考版本，未选作业务 DB | 若选择 PostgreSQL，可评估 RLS 作为数据库补充防线 | 超级用户、BYPASSRLS 和通常的 owner 可绕过，策略的组合也需审核。RLS 不替代 Function+Scope；当前固定 Yunka 消费者的 PostgreSQL事务/幂等兼容性未证明 |

主来源：[ABP 多租户](https://abp.io/docs/latest/framework/architecture/multi-tenancy)、[租户模块](https://abp.io/docs/latest/modules/tenant-management)、[ABP 10.7.0 根许可](https://github.com/abpframework/abp/blob/10.7.0/LICENSE.md)、[Keycloak 26.8.1](https://www.keycloak.org/docs/26.8.1/server_admin/)、[同版许可](https://github.com/keycloak/keycloak/blob/26.8.1/LICENSE.txt)、[PostgreSQL 17 RLS](https://www.postgresql.org/docs/17/ddl-rowsecurity.html)。原始获取与错误均在 raw 中。

固定 Yunka 根清单无 LICENSE，根 LICENSE 请求 404；未核实其他授权位置，不能由公开可读推出商用/分发许可，也不能推出没有适用许可。请权利 Owner 指明实际授权。Vben 本地保留 MIT 许可。此处只报告所读许可事实，不作跨许可可兼容结论。

## 建议责任与数据边界

这是一份待设计冻结的责任图，不新建第二份 API schema。已审 [F0 责任表](raw/local/doc/tasks/issue-11-f0/rounds/r005/design.md) 和 canonical PB 保持权威。

| 责任 | 目标持有者及数据 | 保护条件 |
| --- | --- | --- |
| Identity / Session | 外部身份映射、BFF 会话、会话撤销、CSRF | 只接受已验证凭据；浏览器 userId/tenantId/trace 不能建立 Principal；issuer/sub 映射方案待定 |
| Access | Account、Tenant、Membership、Role、MenuGrant、Function+Scope 当前事实 | 每个请求读当前有效成员/授权；平台身份不隐含租户 Owner；IdP claims 不直接充当业务 Role |
| Application availability | 受控模块目录、生效配置及开通结果 | 独立业务条件；开通模块不授予 IAM permission，拥有 permission 也不能绕过模块关闭 |
| PB / Authorizer / OperationGuard | 唯一 Operation 合同、功能判断、绑定动作/租户/资源的 Scope | API 不查 Console Menu；生成物只读；一个生产 Operation 不能新旧入口同时放行 |
| Domain / Repository | 业务资源、查询、状态、事务、审计、结果回读 | 对列表/详情/写入/批量/导出/统计/后台任务强制 Tenant AND 对应 Scope；客户端条件只能缩小 |
| 结果恢复 | 持久操作 ID、权限域/主体/租户/操作/幂等键、参数摘要、结果状态 | 参数摘要独立于唯一查找键；同键改参冲突；结果和业务效果在可恢复原子边界；查询原结果仍重新授权 |
| Console | 受控视图注册表、导航/动作投影、标签页上下文 | 投影不产生 API 权限；按主体/租户/访问版本隔离缓存，切换丢弃旧响应，失败不回用旧权限 |
| 观测与运维 | 安全关联 ID、可查询 Trace/Log、受控查询/留存 | Trace 不授予身份；故障降级与成本/保留政策须实际 Owner 和环境验证 |

复用：Console shell/主题/i18n/RequestEpoch；固定 Consumer 和生成治理。适配：Mock service→PB 派生真实客户端、V2 seam→Yunka 当前授权适配、Scope→真实仓储。缺口：真实 Session/Access、模块持久权威、Domain/迁移、幂等结果/审计、完整跨端观测与生产。详细分类绑定来源见 [architecture.json](architecture.json)。

数据库建议只限“若组织无既有强制标准，先沿 Yunka 已描述的 MySQL 路径做非生产验证”；这是减少新适配面的推断，不是对现有 DB、具体版本或生产资格的宣布。若组织已有 PostgreSQL，应先评估固定 Consumer 的事务/幂等适配；若有硬性独库要求，必须改变拓扑、迁移和恢复设计。身份建议优先复用现有 OIDC；无现成源时再以明确资源/版本评估 Keycloak。都需实际 Owner 决定。

## 有序纵向路线

| 单元及依赖 | 最小可观察出口 | 必需资源与验证环境 |
| --- | --- | --- |
| A0：本方案审阅 | P1/P2/P3 与数据、身份和隔离约束有精确修订回复；不丢既有义务 | 产品/技术/组织 Owner；本轮为 r002 待审 |
| A1 ← A0：资源及 Consumer 准入 | 固定制品/工具实际可用，生成与 check 零漂移，真实资源可连接与查询 | 隔离非生产环境、archive 权限、锁定工具、DB/IdP/Trace；不得只看 metadata |
| A2 ← A1：F3 依赖子切片 | 真实 Account/Tenant/Membership/Grant、Session/CSRF、0/1/N 与标签页工作区 | 真凭据/DB/API/浏览器；撤销、跨租户、最后 Owner 并发等反例；独立评审 |
| A3 ← A2：F2 营销纵向链 | 保留 #13 完整验收：有 Function 无 Menu 正常使用；深链/越权受拒、无副作用、真实 Trace 可查 | 明确营销动作/Domain Owner、真实 Access/仓储/前后端 Span；本轮未定义营销商业规则 |
| A4 ← A2+A3：F3 与 SAAS-01 闭环 | 真实创建/人工开通/成员加入/角色范围/撤销/恢复，相关 Console 替换 Mock；A–I 完整矩阵 | 同版前后端与迁移、真实非生产、同键并发/改参/首回执丢失及权限组合；产品接受 |
| A5 ← A4：F4 数据边界与 F5 迁移 | CRM/营销各入口按 Tenant AND Scope；统一执行且有兼容/回退、单一放行 | 全入口清单、真实仓储负例；旧 Router 只能在证据齐备并获准后退役 |
| A6 ← A5：F6 生产资格 | 满足已审安全、审计、恢复、性能、观测/留存后，再分别获得发布授权与目标回读 | Owner 定义容量/SLO/RPO/RTO/数据政策/预算、真实环境与演练；缺少任一就不宣称生产完成 |

本路线保持 F0/F1 已交付事实；A2 只是为 F2 准备明确依赖的 F3 子切片，不能提前关闭整个 F3。后续由既有 SDLC 路由恢复实际 Design/Build/Deploy 阶段。本轮没有 dispatch 实现、merge 或部署，也没有安装持续执行服务。
