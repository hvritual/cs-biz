# 通用基础 SaaS 调查与方案 · r002

**方案材料已准备，业务方案待用户审阅；真实 SaaS 能力和生产就绪均未证明。**

建议保留 Yunka 与现有 Console，首版先做真实租户、人工模块开通、成员/角色/范围及一条合法业务操作的完整闭环。沿既有 F2 营销/F3 身份与 Access 义务推进；不要从 Mock 页面或公共技术探针推断系统已经可服务真实租户。

| 阅读目的 | 文件 |
| --- | --- |
| 审阅产品角色、范围、旅程、路线选择 | [business-proposal.md](business-proposal.md) |
| 核对实际消费者、锁、成熟方案与技术路线 | [technical-analysis.md](technical-analysis.md) |
| 查看八项准备好的决定与建议 | [decision-requests.md](decision-requests.md) |
| 看完成边界、criterion 覆盖和未完成项 | [closure-record.md](closure-record.md) |
| 看精确命令、失败和静态检查原始结果 | [validation-results.md](validation-results.md) |
| 复核结构记录与来源绑定 | [goal.json](goal.json)、[assessment.json](assessment.json)、[architecture.json](architecture.json)、[sources.json](sources.json) |

GitHub canonical main 为 `4d5dd75500de601cbadd41ade18c2459c72c23b5`；本地候选为 `aec53bddd7818e8a554c01902342593f894c4dc9`。逐字节对账保留在 raw；候选未冒充 main。初始 r001 与基线漂移失败完整保留，当前 r002 的 checker 返回 `PASS_STATIC_ONLY / HUMAN_DECISION`；真实接受/运行未验证，执行权限为 false。

本轮仅写此任务目录；未更改源码、创建外部 Issue/消息、实现或部署，未读取测试/W06 validation/evidence/其他 Agent 输出或此前对话。外部可读资料、许可矛盾与失败均保留；没有编造访问、用户批准或 SaaS 运行结果。
