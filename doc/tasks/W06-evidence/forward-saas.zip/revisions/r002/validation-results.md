# 实际验证记录 · r002

这是对任务制品和来源绑定的验证，不是应用测试或 SaaS 资格。没有运行 build、单测、端到端、浏览器、真实 DB/API、制品下载/执行或生产回读。

## 原始 checker 运行

| 尝试 | 实际结果 | 精确原件 |
| --- | --- | --- |
| 01，r001 对实际候选 | exit 2，FAIL：live baseline drift；execution_granted=false | [command/hash](raw/goal-check-attempt-01.command.json)、[stdout](raw/goal-check-attempt-01.stdout.json)、[stderr](raw/goal-check-attempt-01.stderr.txt) |
| 02，对账后的 r002 | exit 0，PASS_STATIC_ONLY / HUMAN_DECISION；authentic_approval/runtime=NOT_VERIFIED；execution_granted=false | [command/hash](raw/goal-check-attempt-02.command.json)、[stdout](raw/goal-check-attempt-02.stdout.json)、[stderr](raw/goal-check-attempt-02.stderr.txt) |

执行目录均为 `/workspace/scratch/0fc9dd84ab02/cs-biz`。

第一次实际命令：

```sh
python3 /workspace/scratch/0fc9dd84ab02/cs-biz/.agents/skills/intent-to-outcome-closure/scripts/check_goal.py --task /workspace/scratch/0fc9dd84ab02/w06-forward-saas --live-baseline aec53bddd7818e8a554c01902342593f894c4dc9
```

第二次实际命令：

```sh
python3 -B /workspace/scratch/0fc9dd84ab02/cs-biz/.agents/skills/intent-to-outcome-closure/scripts/check_goal.py --task /workspace/scratch/0fc9dd84ab02/w06-forward-saas --live-baseline aec53bddd7818e8a554c01902342593f894c4dc9
```

两次实际调用的 checker SHA256 均为 `c7833e39c9be06fe9670ad7065dbf5e4c12cd92da3d75a9f74adde247cbd52a8`，各自调用前后相同。最初读取的较早 checker 字节摘要为 `6470c441321bbc4634df7d5354bb2648d57016122dc5057cd04aabff39711479`，其快照保留；没有冒称用旧字节运行过当前结果。当前工作流和 checker 快照在 `raw/revision-r002`，原始版本在 `raw/local`，各资源摘要见 [manifest](raw/workflow-and-extra-source-manifest.json) 和 [source-reconciliation](raw/source-reconciliation.json)。

r001 三个 JSON 原件与生成脚本保存在 `revisions/r001`；失败后没有改原件去假装初次成功。实际对账证明已读应用/产品字节不变，协调资源的变化已被读取并绑定至新 revision。当前 basis 为 `7a1f3533810ddf451d4a8b365b67f60dbf341ce45c8db0c8f374b858c27140f1`。

checker 先列出 P1/P2/P3；它没有声明 T1–T5 已解决。产品与架构共八项 response 均为 null，用户审阅依然待完成。

## 只读环境与源观察

完整 argv/目录/exit/stdout/stderr 位于 [inspection-commands.json](raw/inspection-commands.json)。

| 命令或观察 | 实际结果 | 含义 |
| --- | --- | --- |
| `git rev-parse HEAD`（初始） | 4d5dd75500de601cbadd41ade18c2459c72c23b5 | 初始本地版本；之后发生推进，未假装仍是该版 |
| GitHub main，两次独立读取 | 4d5dd75500de601cbadd41ade18c2459c72c23b5 | canonical main 读回；本地候选不是 main |
| 当前本地 HEAD | aec53bddd7818e8a554c01902342593f894c4dc9 | 当前只读分析候选；应用/产品原字节已逐文件对账 |
| `command -v go` / `docker` / `yunka` | 各 exit 1，无 stdout | 当前 PATH 未找到；不推断其他安装位置，也不记为环境合格 |
| `node --version` | exit 0，v24.19.0 | 实际可见版本 |
| `pnpm --version` | exit 0，11.25.0 | 不同于项目固定 10.33.4；未安装/替换工具 |
| 生产 Go 文件清单、Mock 身份/存储 rg | exit 0，原始输出已留 | 源级消费者事实，不能替代运行结果 |

## 外部检索与失败

[retrieval-log.json](raw/retrieval-log.json) 记录实际工具与参数、原始 payload 路径及每次结果。24 项调用均有原始文件；Web 只有官方主来源用于技术结论。工具未提供每次调用时钟，记录明确区分检索日期与保存时间。

- 通用 GitHub fetch 对 `/license`、直接 `/actions/artifacts/{id}` 返回工具 allowlist 拒绝；原文保留。随后通过已支持的 workflow-run artifacts 工具读到目标制品 metadata，未下载或执行。
- 固定 Yunka 根 LICENSE、ABP 错误猜测的 LICENSE 文件请求为 404；之后读根清单观察实际 LICENSE.md，并成功读取 ABP 同版 LGPL v3。没有重试相同失败动作。
- Keycloak 26.8.1 同版 LICENSE.txt 可读（Apache 2.0）。ABP 模块文档 MIT 声明与发布根许可差异保留为反证，未擅自推断整体复用许可。
- 制品 metadata 的 digest、过期字段和时间匹配本地锁，只证明元数据一致；真实 zip/tar/manifest 字节与 Consumer 运行资格未验证。
- 文件序列化曾因缺失 `btoa`、shell 参数过长而失败；[authoring-failures.txt](raw/authoring-failures.txt) 保留原错误与具体修复。它们不是外部访问失败，也没有转写为成功记录。

## 最后制品回读

实际读取 37 个绑定引用、30 个本地 Markdown 链接，解析原始 GitHub JSON，并核对 local HEAD/checker 摘要。结果：`FAILED`，问题数 1。原始明细见 [artifact-readback.json](raw/artifact-readback.json)。这只验证保存、引用和绑定完整性，不证明语义审批或应用运行。
