from pathlib import Path
import hashlib,json,datetime,importlib.util
root=Path('/workspace/scratch/0fc9dd84ab02/w06-forward-saas')
repo=Path('/workspace/scratch/0fc9dd84ab02/cs-biz')
sha='4d5dd75500de601cbadd41ade18c2459c72c23b5'
def save(name,value):
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n' if not isinstance(value,str) else value)
def ref(p):return {'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()}
raw='''原始用户请求：我想使用 yunka.io 框架构建通用基础 SaaS 管理系统。请结合现有工程和可访问的外部成熟方案自主调查，给出我能审阅的业务方案，并完成实际技术状况分析与技术路线；遇到需要我的地方，先准备好选择与建议。\n\n本次授权：只读源码检查和可访问的外部检索；task-local 原始证据、goal records、业务与架构输出只可写入 /workspace/scratch/0fc9dd84ab02/w06-forward-saas。不得修改源码、创建外部 Issue/消息、实施或部署。不得阅读测试、W06 validation/evidence、其他 Agent 输出或先前对话。\n\n实际边界：形成待 Human 审阅的方案与技术分析；不声称方案已被接受、真实 SaaS 已工作或生产已就绪。\n'''
save('raw/intent-and-authority.txt',raw)
save('raw/budget-policy.txt','遵循所读技能与根 AGENTS：最多两次实质相同且没有新信息的失败；维护累计原始尝试。检索以材料问题有充分证据为止，不为补齐渠道而制造访问。本次没有重复相同被拒请求。外部写入/下载运行/实现均未授权。\n')
sources=[]
def src(i,channel,locator,version,path):sources.append({'id':i,'channel':channel,'locator':locator,'version':version,'artifact_ref':ref(path)})
local={
'L-PRODUCT':'doc/product/scope.md','L-JOURNEY':'doc/journeys/SAAS-01-tenant-onboarding.md','L-ARCH':'doc/architecture/README.md','L-CONTRACT':'doc/contracts/README.md','L-MOCK':'frontend/apps/console/src/api/mock/service.ts','L-WORKSPACE':'frontend/apps/console/src/store/workspace.ts','L-AUTHZ':'backend/internal/platform/authz/authorize.go','L-PROBE':'backend/internal/runtime/probe/probe.go','L-PB':'backend/contracts/proto/runtime/v1/runtime.proto','L-LOCK':'backend/.yunka/consumer-lock.json','L-MOD':'backend/go.mod','L-ADR':'doc/architecture/adr/0003-yunka-f0-consumer-contract.md','L-ACCESS':'doc/contracts/access-context.md','L-F0':'doc/tasks/issue-11-f0/rounds/r005/design.md','L-FRONT-PKG':'frontend/package.json','L-VBEN-LICENSE':'frontend/LICENSE.vben'}
for i,p in local.items():src(i,'local',str(repo/p),sha+' + exact working-tree snapshot; see artifact sha256','raw/local/'+p)
external=[
('G-MAIN','github','https://api.github.com/repos/hvritual/cs-biz/branches/main',sha,'github-main'),
('G-PRS','github','https://api.github.com/repos/hvritual/cs-biz/pulls?state=open&per_page=100','observed 2026-10-16; 7 entries, one page','github-prs'),
('G-F2','github','https://github.com/hvritual/cs-biz/issues/13','open as retrieved 2026-10-16','issue-13'),
('G-F3','github','https://github.com/hvritual/cs-biz/issues/14','open as retrieved 2026-10-16','issue-14'),
('G-YUNKA','github','https://github.com/hvritual/yunka.io/blob/bc7c0e1dd6b4e815951130c7acfbf60371445453/README.md','bc7c0e1dd6b4e815951130c7acfbf60371445453','yunka-readme'),
('G-YUNKA-ROOT','github','https://api.github.com/repos/hvritual/yunka.io/contents?ref=bc7c0e1dd6b4e815951130c7acfbf60371445453','bc7c0e1dd6b4e815951130c7acfbf60371445453','yunka-root'),
('G-ARTIFACT','github','GitHub workflow run hvritual/yunka.io/38734324861 artifacts list','artifact 11971414833; digest 5aece1d69b7708dfede53406d634dbc03aafb234ebe71d3df7f8a911b4ae69fd','yunka-artifacts-list'),
('G-ABP-RELEASE','github','https://api.github.com/repos/abpframework/abp/releases/latest','10.7.0 published 2026-10-06T10:30:21Z','abp-release'),
('G-ABP-LICENSE','github','https://github.com/abpframework/abp/blob/10.7.0/LICENSE.md','10.7.0; LGPL v3 text','abp-license-tag-md'),
('G-KC-RELEASE','github','https://api.github.com/repos/keycloak/keycloak/releases/latest','26.8.1 published 2026-10-13T08:58:15Z','keycloak-release'),
('G-KC-LICENSE','github','https://github.com/keycloak/keycloak/blob/26.8.1/LICENSE.txt','26.8.1; Apache 2.0','keycloak-license-tag'),
('W-ABP','official_docs','https://abp.io/docs/latest/framework/architecture/multi-tenancy','latest documentation retrieved 2026-10-16; not pinned to release','web-primary'),
('W-ABP-TENANT','official_docs','https://abp.io/docs/latest/modules/tenant-management','latest documentation retrieved 2026-10-16; separate commercial SaaS module','web-primary'),
('W-KC','official_docs','https://www.keycloak.org/docs/26.8.1/server_admin/','26.8.1; Organizations section','primary-details'),
('W-PG','official_docs','https://www.postgresql.org/docs/17/ddl-rowsecurity.html','PostgreSQL 17 documentation; deliberate reference version, not selected DB','primary-details')]
for i,c,l,v,f in external:src(i,c,l,v,'raw/'+f+'.txt')
criteria=[
('C1','给定当前仓库和真实 GitHub 可读源','按版本观察合同、源码、锁与 main/PR','产出事实和未证明边界，能定位原始字节','未合并候选不得记为 main；Mock 不得记为真实 IAM','源漂移则保留旧快照并重核受影响结论','raw/baseline.json、源码快照、GitHub 原始返回和技术分析交叉核对','本地工作树与 GitHub 只读；不含应用运行'),
('C2','给定可访问的成熟主来源','比较 SaaS 分层、身份、多租户隔离及复用条件','至少两条可行路线有适配、限制、反证与出处','访问失败、版本差异和许可矛盾必须保留','改用可用的官方入口；仍不可得则形成资源请求','raw/web-primary.txt、primary-details.txt、发布和许可原件','官方文档/GitHub 检索；不证明本项目运行兼容'),
('C3','给定现有产品与 SAAS-01','归纳角色、范围、主流/拒绝/未知结果/恢复','业务方案可审阅并区别显式、必要与可选工作','不得添加未批准价格、支付或行业全套需求','由 Human 对具体方案修订给反馈；只重开受影响分支','business-proposal.md 与 assessment.json 可逐条回溯原需求','待审提案，尚非已冻结需求'),
('C4','给定现有消费者和材料性未决资源','单独形成架构现状、复用/适配/缺口及有序路线','每一纵向单元有依赖、可观察出口、环境和资源','生成物/技术探针不得被当业务服务或生产资格','材料性选择返回具体 Owner；不造替代系统','technical-analysis.md 与 architecture.json 对照源快照','源级技术分析，未运行 build/应用/真实数据验证'),
('C5','给定已调查的材料性缺口','为 Human 准备事实、选项、建议、影响、Owner 与动作','decision-requests.md 和 JSON 留有明确待答记录','无回复不得变成批准；资源访问不等于变更授权','保存实际反馈后绑定修订，保留原件','逐项检查 decisions 的事实源、可行选项及 response=null','决策准备边界；未发送给其他人'),
('C6','给定精确版本的本提案与原始证据','用户审阅缺失必需工作、越界、证据和完成声明','只有真实反馈记录才能把待审变为已接受','静态检查 PASS 不是用户接受或业务完成','按真实回复创建下一修订；不更改本轮原证据','需要用户对本轮版本给出实际审阅；当前没有回复','Human 审阅待完成')]
cs=[dict(zip(['id','given','when','then','negative','recovery','verification','environment'],x)) for x in criteria]
req=[
{'id':'R1','classification':'explicit','rationale':'用户明确要求结合现有工程与可访问成熟方案调查。','source_ids':['L-PRODUCT','G-MAIN','W-ABP','W-KC'],'criterion_ids':['C1','C2']},
{'id':'R2','classification':'explicit','rationale':'用户明确要求可审阅的业务方案。','source_ids':['L-PRODUCT','L-JOURNEY'],'criterion_ids':['C3','C6']},
{'id':'R3','classification':'explicit','rationale':'用户明确要求实际技术状况分析与技术路线。','source_ids':['L-PROBE','L-AUTHZ','L-LOCK','G-F2','G-F3'],'criterion_ids':['C4']},
{'id':'R4','classification':'explicit','rationale':'用户要求先准备需要其参与的选项与建议。','source_ids':['G-F2','G-F3','L-ADR'],'criterion_ids':['C5']},
{'id':'R5','classification':'derived','rationale':'C1/C2/C4 要求可核对事实，必须保留源版本、失败/反证、许可和工具边界，否则不能审阅兼容性与现状。','source_ids':['L-CONTRACT','G-ABP-LICENSE','G-YUNKA-ROOT'],'criterion_ids':['C1','C2','C4']},
{'id':'R6','classification':'derived','rationale':'C3/C4/C6 必须保持 canonical 业务目标、已审架构与候选/实现/运行/接受的区别，防止本次分析改写原承诺。','source_ids':['L-JOURNEY','L-ADR','L-F0'],'criterion_ids':['C3','C4','C6']},
{'id':'R7','classification':'optional','rationale':'计费支付、复杂组织委派、跨租户协作、IoT 与完整行业模块不是本次提案闭环的必要工作，留待业务定义。','source_ids':['L-PRODUCT'],'criterion_ids':[]}]
def dec(i,kind,owner,facts,sids,missing,options,recommended,impact,action):return {'id':i,'kind':kind,'owner':owner,'facts':facts,'source_ids':sids,'missing':missing,'options':[{'id':a,'description':b,'tradeoffs':c} for a,b,c in options],'recommended':recommended,'impact':impact,'action_needed':action,'response':None}
pdec=[
dec('P1','业务范围与接受','产品 Owner / 用户',['现有产品把真实租户开通→成员授权→一次真实操作列为首个成果。','价格、支付、到期、退款等规则尚未定义。'],['L-PRODUCT','L-JOURNEY'],'首版是内部/试点基础平台，还是必须立即商业售卖？',[('foundation','首版聚焦平台租户/模块、租户成员/角色/范围与一条真实业务链','最少商业假设；付费商业化延期。'),('commercial','首版包含订阅与收费','需要另行确定价格、税费、支付、退款、到期和对账；扩展验收及资源。')],'foundation','决定产品分母和后续设计边界；本次仍只交付提案。','审阅 business-proposal.md 后选 foundation/commercial，并列出首版不能缺少的业务结果。'),
dec('P2','首条业务路线','产品 Owner / 技术 Owner',['F2 #13 已明确营销 Function-only，要求无 Console Menu 也可执行合法动作。','当前 Console 有客户页，但没有真实 CRM API。'],['G-F2','L-MOCK','L-PRODUCT'],'保留已规划的营销试点，或申请重设先后顺序？',[('keep-f2','保留营销 F2；F3 先提供其依赖的真实身份/Access 子切片，CRM 随 F4','复用当前验收且避免重做；营销 Domain 仍需具体定义。'),('rebaseline-crm','先做 CRM 客户最小链并显式修订 F2/依赖','对现有 Console 更直观，但不能声称满足原营销验收，需设计变更。')],'keep-f2','决定第一条真实 Operation 和所需业务人员；两条路线都不能用虚构身份替代。','确认保留 F2，指定一项真实营销动作及其业务 Owner；若改 CRM，明确同意重审受影响验收。'),
dec('P3','成员加入方式','产品 Owner / 组织管理员',['当前成员创建只是本地记录，不发送邀请。','SAAS-01 要求实际加入状态及回执恢复。'],['L-PRODUCT','L-JOURNEY','L-MOCK'],'首期成员如何取得真实身份并加入租户？',[('controlled-link','受控加入链接，由管理员按既定渠道交付；系统只宣称链接/加入事实','避免先依赖邮件发送；仍需一次性、失效、角色范围与审计设计。'),('directory','使用现有组织 IdP/目录驱动的受控加入','可复用组织流程；需要现成目录、映射和撤销规则。')],'controlled-link','影响邀请模型、通知依赖和真实验收；已有组织目录时优先复用。','指定首批用户来源与加入方式；若需系统发邮件，另给可用通道与送达接受标准。')]
tdec=[
dec('T1','数据库选择','技术 Owner / 数据与运维 Owner',['go.mod 的 MySQL/GORM 是间接依赖，不证明已采用业务 DB。','固定 Yunka README 描述 MySQL 能力与持久幂等路径；当前消费者没有业务仓储或迁移。'],['L-MOD','L-PROBE','G-YUNKA'],'哪个数据库及隔离模式具备实际组织支持？',[('mysql','沿 Yunka 已描述的 MySQL 路径先做真实非生产验证','预计新增适配较少，这是源级推断；具体受支持发行版、迁移与事务仍需验证。'),('postgres','选择组织既有 PostgreSQL，并先做 Yunka 兼容与事务/幂等适配评估','RLS 可作为防线；当前固定消费者兼容性未证明，新增验证工作。')],'mysql','阻塞真实持久 Access 和业务写入；不选择版本号或采购资源。','提供组织既有 DB 标准、可用非生产实例和数据边界；确认选项及是否要求每租户物理隔离。'),
dec('T2','身份与会话资源','身份/安全 Owner / 技术 Owner',['当前浏览器 selectUser 不验证凭据。','F3 要求可信 BFF/IdP/Session/CSRF、会话撤销与 0/1/N 租户。'],['L-MOCK','G-F3','W-KC'],'是否已有可复用 OIDC IdP 和非生产客户端？',[('reuse-oidc','优先复用组织既有 OIDC；Console 通过 BFF 会话接入','复用账户治理；需 issuer、client、回调、退出及测试主体。'),('keycloak','没有既有源时评估固定 Keycloak 26.8.1 的独立非生产实例','Apache 2.0 来源已读；新增运维与恢复成本，未验证 cs-biz 接入。')],'reuse-oidc','身份选择影响 Account 映射、邀请、吊销和浏览器/CSRF验收；Keycloak Organization 不替代业务 Access。','确认已有 IdP 与 Owner；仅提供 issuer/客户端元数据及申请方式，不在文档贴密钥。无现成源时批准单独评估 Keycloak 的范围与资源。'),
dec('T3','隔离与租户数据政策','产品/安全/数据 Owner',['SAAS-01 要求两个租户真实持久资源与 Tenant AND Scope。','ABP 提供共享/独库/混合模式参照；模式不能替代操作范围检查。'],['L-JOURNEY','L-AUTHZ','W-ABP'],'是否存在合同、地区或合规要求强制独库/独部署？',[('shared-pilot','无硬性独库要求时，非生产试点先共享库/显式 tenant 键与操作范围','运维较小；必须证明列表/详情/写入/导出等隔离，不能只有 ORM 过滤。'),('dedicated','存在隔离要求则设计每租户独库或独部署','缩小共享数据影响面；迁移、连接路由、备份与成本增加，当前未实现。')],'shared-pilot','会改变 DB 模型、部署拓扑、成本与恢复设计；推荐只适用于确认没有强制隔离要求的试点。','确认首批租户的数据类别、地域和硬隔离要求；不能以沉默当作无要求。'),
dec('T4','测试环境与后续执行权限','环境/安全 Owner / 用户',['本环境 PATH 无 go、docker、yunka；全局 pnpm 11.25.0 与项目 10.33.4 不同。','锁定制品元数据未过期且摘要相符，但未下载/运行。'],['L-LOCK','G-ARTIFACT','G-F3'],'谁提供真实非生产 DB/IdP/浏览器/可查询 Trace 及独立验证？',[('prepare-env','准备组织非生产环境与凭据申请，再授权独立设计/实现切片','可取得真实证据；需要资源 Owner 和单独执行范围。'),('analysis-only','暂保留方案，不进入实现','无资源成本；真实 SaaS 能力保持未证明。')],'prepare-env','本次分析可以完成；后续真实闭环不能只靠当前环境或 Mock。','指定环境 Owner、可用资源和审阅人；后续实现/外部变更/部署授权分别给出。'),
dec('T5','源码复用权属资源','Yunka 仓库/权利 Owner',['固定 Yunka root 清单无 LICENSE；请求根 LICENSE 返回 404。','这只证明此次未核实许可，不证明不存在其他授权。','ABP 文档模块 MIT 声明与 10.7.0 根 LGPL v3 必须按实际复用边界核对。'],['G-YUNKA-ROOT','G-ABP-LICENSE','W-ABP-TENANT'],'商用/对外分发采用何种实际授权？',[('supply-grant','由权利 Owner 提供 Yunka 适用授权/内部复用依据；成熟外部方案先只借鉴边界','维持现有技术方向；直接复制前需核对具体文件与条款。'),('hold-distribution','权属未核实前仅保留分析，不承诺公开分发/商业发布','继续做方案审阅；发布相关分支受阻。')],'supply-grant','不阻断本次只读分析；影响后续商用/公开分发承诺。','请仓库权利 Owner 指明适用授权文件或许可决定及覆盖范围；不要把公开可读当作复用许可。')]
options=[
{'id':'extend','description':'沿现有 Yunka Consumer 与 Vue/Vben Console 扩建通用基础 SaaS；以真实租户与 Access 纵向闭环为首版。','tradeoffs':'保留既有工程与已审边界；仍需自建 Access 持久化、BFF/会话和具体业务域。','counterevidence':'F1 只有公共技术探针；没有真实 SaaS 业务服务，不可把外部框架能力当成本地已装配。','source_ids':['L-PRODUCT','L-ADR','L-PROBE','G-F2','G-F3']},
{'id':'replace','description':'采用完整成熟平台的 SaaS 组合，或改用 ABP 体系作为主要底座。','tradeoffs':'可复用更多现成模块；需要 .NET 技术栈迁移、前端/权限模型对账与许可预算。','counterevidence':'用户指定 Yunka；ABP 商业 SaaS 和开源租户模块不是一回事，根发布许可也不等于文档模块 MIT 声明。','source_ids':['W-ABP','W-ABP-TENANT','G-ABP-LICENSE','L-ADR']},
{'id':'identity-first','description':'保持 Yunka，先接成熟 OIDC IdP，只做真实登录/租户选择，再逐步加入通用管理。','tradeoffs':'先消除身份伪造的核心前提，能缩小第一切片；单独 IdP 不提供业务 Tenant AND Scope、模块权益、幂等结果。','counterevidence':'只有登录不能满足 SAAS-01 或 F2；不能把 IdP Organization 与 cs-biz Tenant/Grant 直接等同。','source_ids':['W-KC','L-JOURNEY','G-F2','G-F3']}]
goal={'protocol':'goal-progress-v1','goal_id':'forward-saas-research','revision':'r001','mode':'real','baseline_sha':sha,'raw_ref':ref('raw/intent-and-authority.txt'),'feedback_refs':[],'authority_ref':'raw/intent-and-authority.txt — actual user request and parent-delegated read-only/write-only-task scope; no execution grant','requested_boundary':'reviewed_design','required_channels':['local','github','official_docs'],'sources':sources,'searches':[
{'channel':'local','query':'Inspect AGENTS/map/product/SAAS-01/ADR/contracts and selected production consumers/locks; exclude tests/W06 evidence/other-agent output.','status':'observed','source_ids':list(local),'reason':'Exact source snapshots and hashes retained; source findings are not runtime proof.'},
{'channel':'github','query':'Read cs-biz main/open PRs/#13/#14, fixed Yunka README/root/artifact metadata and mature-system release/license files.','status':'observed','source_ids':[x[0] for x in external if x[1]=='github'],'reason':'Main readback and raw files available; artifact metadata only, no archive download or binary qualification.'},
{'channel':'official_docs','query':'Official ABP multi-tenancy/tenant management, Keycloak Organizations 26.8.1, PostgreSQL 17 row security.','status':'observed','source_ids':[x[0] for x in external if x[1]=='official_docs'],'reason':'Primary references inspected for responsibility fit and counterevidence; latest ABP docs are not release-pinned.'},
{'channel':'github','query':'Generic fetch /license endpoints and direct /actions/artifacts/11971414833; root LICENSE guesses.','status':'unavailable','source_ids':[],'reason':'Generic tool allowlist rejected endpoint families; fixed Yunka LICENSE 404 and ABP LICENSE 404 retained. Switched to documented artifact-list tool and observed LICENSE.md file; no repeated denied request.'}],
'budget':{'policy_ref':'raw/budget-policy.txt','max_without_progress':2,'attempts_without_progress':0},'records':{}}
spec=importlib.util.spec_from_file_location('goal_checker',root/'raw/local/.agents/skills/intent-to-outcome-closure/scripts/check_goal.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
basis=module.basis(goal)
assessment={'basis_sha256':basis,'route':'software','background':'现有工程拥有 Mock Console、Authz V2 与有限 Yunka 技术 Consumer。用户要求通用基础 SaaS 的可审阅业务方案和真实技术分析；本轮不实现。','impact':'把页面/技术探针与真实 SaaS 闭环分开，复用 canonical 目标与已审边界，先准备业务与资源决定，避免无凭据/数据库条件下制造完成声明。','goals':['让产品 Owner 可审阅通用基础 SaaS 的首版分母与角色旅程。','让技术 Owner 能从确切消费者、合同和锁定位复用/适配/缺口。','准备必要 Human 输入而不把假设当选择。'],'flows':['平台管理员创建租户与人工开通模块，回读持久权益/操作结果；无权限与非法配置拒绝。','租户负责人以真实身份进入 0/1/N 企业路径，建立成员并配置 Role 与 Function+Scope；超范围委派与最后 Owner 破坏被阻止。','成员在当前标签页工作区执行合法 Operation；没有 Console Menu 仍可按营销 Function 使用独立入口，API 不依赖菜单。','跨租户、只读写入、停用、无模块/无 Function 时 API 拒绝且无副作用；撤销后按当前权威重验。','创建/开通回执丢失保留预存幂等键并查询结果；切租户迟到响应丢弃、恢复不自动重放命令。'],'options':options,'recommended':'extend','requirements':req,'criteria':cs,'decisions':pdec}
save('assessment.json',assessment);goal['records']['assessment']=ref('assessment.json')
compat=[
('Console shell/theme/i18n/view registry','reuse','现有界面、主题、语言和受控菜单可保留；本轮没有浏览器验收。',['L-WORKSPACE','L-MOCK']),
('本地 service → typed HTTP client','adapt','store 直接依赖 mock/service；将保持上下文 generation/缓存隔离语义，逐 slice 接已审 canonical PB 派生客户端。',['L-WORKSPACE','L-MOCK','L-CONTRACT']),
('Yunka Consumer/CLI/PB/assembly ownership','reuse','固定模块、SDK/producer 分开和只读派生物规则保留；元数据相符不替代二进制下载与生成资格。',['L-LOCK','L-PB','L-ADR','G-ARTIFACT']),
('可信身份/Session/BFF/CSRF','gap','现状 selectUser 只改变浏览器会话 ID，无可信适配或真实凭据链。',['L-MOCK','G-F3']),
('Access 当前权威','gap','V2 CurrentAuthority 是接口，当前消费者未装配持久 Membership/Role/Grant；IdP 只负责身份。',['L-AUTHZ','L-PROBE','G-F3']),
('Function PEP + Scope + domain repositories','adapt','保留动作范围关联和旧兼容内核；目标沿 Authorizer→OperationGuard→Domain，禁止同 Operation 双入口放行。',['L-AUTHZ','L-F0','G-F2']),
('Tenant/module availability/audit/recovery','gap','本地实体/流程不是数据库服务；需独立业务权威和原子结果/查询恢复。',['L-JOURNEY','L-ACCESS','L-PROBE']),
('生产可观测性与发布','gap','本地 probe 查询描述不证明真实浏览器业务 Span、安全查询/留存、生产环境与恢复资格。',['L-PROBE','G-F2','G-F3'])]
roadmap=[
{'id':'A0','depends_on':[],'outcome':'审阅本轮 r001，确认 P1/P2/P3、DB/IdP/隔离与 Owner；沿既有 Design 形成同版边界，不重开已交付 F0/F1。','verification':'产品/技术 Owner 对精确修订给真实反馈；核对原 SAAS-01、F2/F3 义务不丢失。','resources':['用户实际审阅','真实组织约束','本轮只读证据；未来实现另授权']},
{'id':'A1','depends_on':['A0'],'outcome':'真实非生产资源和固定 Consumer 资格准入；确认锁到期、精确 Go/protoc/CLI、可写 DB、OIDC 测试客户端与可查询 Trace。','verification':'在命名隔离环境记录制品下载摘要、生成/check 零漂移、真实资源连接和有权限查询；本轮未执行。','resources':['F1 既有资格规则','artifact read 权限与固定 archive','Go1.26.9/protoc3.21.12','DB/IdP/Trace Owner']},
{'id':'A2','depends_on':['A1'],'outcome':'F3 最小依赖切片：Account/Tenant/Membership/Role/FunctionScope 当前存储，真实 Session/CSRF 与 0/1/N 标签页上下文。','verification':'命名 DB/API/浏览器验证真实凭据、A/B 两租户两标签、撤销、CSRF、最后 Owner 并发和失败恢复；独立同版审阅。','resources':['D2/D3 实际选择','真实测试账户','版本化迁移','组织非生产环境']},
{'id':'A3','depends_on':['A2'],'outcome':'F2 营销 Function-only 纵向 Operation：canonical PB→REST/可选RPC→可信 Principal→GrantResolver→Scope Guard→真实 Domain/readback。','verification':'有 Function 无 Menu 合法营销成功、Console 深链拒绝；跨租户/无权/禁用/模块关闭拒绝无副作用；真实浏览器→Domain Span 可安全查询；保留原 #13 全分母。','resources':['营销业务 Owner 与真实动作定义','生成客户端与 PB','真实 DB/Trace','实际实现授权']},
{'id':'A4','depends_on':['A2','A3'],'outcome':'完成 F3 与 SAAS-01 的租户创建、模块人工开通、成员加入/撤销、角色与范围及操作结果恢复；真实 Console 替换相应 mock。','verification':'SAAS-01 A–I 矩阵在固定前后端/迁移版本全覆盖，含同键并发一个业务结果、改参409、首回执丢失恢复和授权组合不扩权；外部送达只按真实渠道证明。','resources':['已审邀请/开通语义','事务/幂等结果库','跨端真实环境','独立审阅与产品接受']},
{'id':'A5','depends_on':['A4'],'outcome':'F4 真实 CRM/营销列表、详情、写入、批量、导出、统计强制 Tenant AND 对应动作 Scope；F5 统一执行链受控迁移。','verification':'按源合同列全入口和后台任务负例，直调 API、分页/计数无泄漏；同一 Operation 只有一条生产放行链，保留回退与兼容证据。','resources':['真实仓储/业务数据定义','旧入口清单','相应设计/实现授权']},
{'id':'A6','depends_on':['A5'],'outcome':'F6 才进入生产资格：真实环境安全、审计、幂等/恢复、备份演练、性能和可查询观测，再单独申请发布与回读。','verification':'依已审容量/SLO/RPO/RTO/留存要求测量；独立发布批准、目标版本和生产权威回读，不将测试或 merge 当上线。','resources':['运维/安全与业务 Owner','许可/预算/地区/数据政策','生产目标与部署权限','真实负载及恢复环境']}]
architecture={'basis_sha256':basis,'assessment_sha256':goal['records']['assessment']['sha256'],'current_state':['本地 HEAD 和 GitHub main 均 4d5dd75500de601cbadd41ade18c2459c72c23b5；工作树存在他人未提交工作，逐文件字节快照另绑定。','前端 store 直接导入 mock/service，service 用 localStorage 保存实体、sessionStorage 保存所选账户；没有真实登录证据。','后端可写 PB 仅 runtime.inspect public/no transaction/no idempotency；probe 只注册 loopback gRPC、deny-all 非公共授权，无业务数据。','Authz V2 具 CurrentAuthority seam 与动作 Scope 约束，但 probe 不装配真实 Access。','固定 SDK bc7c0e1…，producer 3e46ec4…，artifact11971414833 元数据摘要/到期匹配；未下载或运行。','Go/docker/yunka 不在 PATH；node v24.19.0，pnpm11.25.0 与声明10.33.4不同。本次没有 build、测试、应用、DB/API、浏览器或生产验证。'],
'patterns':[
{'name':'ABP 的租户存储与独立管理边界','fit':'共享/独库/混合是可比较的存储策略；租户管理、权限和商业 SaaS 功能应分开评估。','limitations':'技术栈不同，不能直接纳入 Go/Yunka；latest 文档与 10.7.0 发布未必同版，模块 MIT 文档声明不能覆盖根 LGPLv3。','source_ids':['W-ABP','W-ABP-TENANT','G-ABP-LICENSE','G-ABP-RELEASE']},
{'name':'成熟 OIDC IdP 与 B2B Organization','fit':'复用认证、组织化加入与身份联邦；由 BFF 验证身份，Access 持有业务成员与 Function+Scope。','limitations':'Keycloak Organization 的 managed/unmanaged 生命周期不同；IdP 成员状态/token 声明不替代当前业务撤权与数据范围。未接入本项目。','source_ids':['W-KC','G-KC-LICENSE','G-KC-RELEASE','G-F3']},
{'name':'数据库行安全作为补充防线','fit':'若选 PostgreSQL，可在应用 Tenant AND Scope 外评估 RLS。','limitations':'超级用户/BYPASSRLS 和通常的表所有者可绕过；策略组合需审核。不是选择 PostgreSQL 的充分条件，也不证明当前兼容。','source_ids':['W-PG','L-AUTHZ']},
{'name':'单一 typed Operation 执行权威','fit':'沿现有 PB/Consumer/Executor 方向，以真实 GrantResolver、OperationGuard、Domain 持久回执补齐业务链。','limitations':'当前只有 public probe，生成 OpenAPI/TS/装配存在不是业务 REST、事务或权限已验证。','source_ids':['L-F0','L-PB','L-PROBE','L-LOCK']}],
'compatibility':[{'area':a,'disposition':b,'reason':c,'source_ids':d} for a,b,c,d in compat],'roadmap':roadmap,'decisions':tdec}
save('architecture.json',architecture);goal['records']['architecture']=ref('architecture.json');save('goal.json',goal)
save('sources.json',{'as_of':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_boundary':'exact task-local snapshots; local HEAD does not identify dirty bytes; tool messages are retrieved data, not authority','sources':sources})
print(json.dumps({'goal':str(root/'goal.json'),'basis_sha256':basis,'sources':len(sources),'product_decisions':len(pdec),'technical_decisions':len(tdec),'criteria':len(cs)},ensure_ascii=False))
