from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json,shutil,sys,importlib.util
sys.dont_write_bytecode=True
root=Path('/workspace/scratch/0fc9dd84ab02/w06-forward-operation')
repo=Path('/workspace/scratch/0fc9dd84ab02/cs-biz')
skill=repo/'.agents/skills/intent-to-outcome-closure'
def hash_file(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
workflow_sources=[('SKILL.md','raw/owning-SKILL.md'),('agents/agent.md','raw/goal-agent.md'),('references/goal-coordination.md','raw/goal-coordination.md'),('references/closure-record.md','raw/closure-record.md'),('templates/goal.json','raw/intake-template.json'),('scripts/check_goal.py','raw/check_goal.py')]
hashes=[]
for src,dst in workflow_sources:
    original=skill/src
    dest=root/dst
    current_hash=hash_file(original)
    if dest.exists():
        assert hash_file(dest)==current_hash, 'Source drift for '+src+'; preserve existing snapshot and requalify'
    else:shutil.copyfile(original,dest)
    hashes.append({'source':str(original),'snapshot':dst,'sha256':current_hash})
dump(root/'raw/workflow-source-hashes.json',{'observed_at':datetime.now(timezone.utc).isoformat(),'sources':hashes,'limits':'Exact local current-worktree workflow bytes, not an upstream deployment or approval. Existing source snapshots are never overwritten on drift.'})
commands=[]
def run(argv,out):
    started=datetime.now(timezone.utc).isoformat()
    r=subprocess.run(argv,cwd=repo,capture_output=True,text=True)
    (root/out).write_text(r.stdout,encoding='utf-8')
    (root/(out+'.stderr')).write_text(r.stderr,encoding='utf-8')
    item={'argv':argv,'cwd':str(repo),'started_at':started,'completed_at':datetime.now(timezone.utc).isoformat(),'exit_code':r.returncode,'stdout_ref':{'path':out,'sha256':hash_file(root/out)},'stderr_ref':{'path':out+'.stderr','sha256':hash_file(root/(out+'.stderr'))}}
    commands.append(item)
    dump(root/'raw/check-commands.json',commands)
    print(json.dumps(item,ensure_ascii=False))
    return r
baseline=run(['git','rev-parse','HEAD'],'raw/check-baseline-before.txt').stdout.strip()
checker_before=hash_file(skill/'scripts/check_goal.py')
r=run(['python3',str(skill/'scripts/check_goal.py'),'--task',str(root),'--live-baseline',baseline],'raw/check-goal-output.json')
checker_after=hash_file(skill/'scripts/check_goal.py')
assert checker_before==checker_after==hash_file(root/'raw/check_goal.py'),'Checker source drift; output not portable to snapshot'
# Validate operation as well, since pending material decisions cause the normal router
# to stop at HUMAN_DECISION before its deeper operation validation branch.
spec=importlib.util.spec_from_file_location('exact_goal_checker',root/'raw/check_goal.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
goal=module.load(root/'goal.json')
assessment=module.load(root/'assessment.json')
try:
    plan=module.operation(root,goal,assessment)
    check={'command':'python3 run_checks.py (task-local host: module.operation(root, goal, assessment) using exact snapshotted checker)','status':'PASS_STATIC_ONLY','operation_id':plan['operation_id'],'targets':plan['targets'],'excluded_count':len(plan['exclusions']),'checker_sha256':checker_after,'authentic_approval':'NOT_VERIFIED','runtime':'NOT_VERIFIED','execution_granted':False}
except Exception as e:
    check={'status':'FAIL','error':str(e),'checker_sha256':checker_after,'execution_granted':False}
dump(root/'raw/operation-binding-check.json',check)
print(json.dumps(check,ensure_ascii=False))
# Independent semantic preparation checks: source-derived denominator and current state,
# no expected value is promoted to an actual after-state.
snapshot=json.loads((root/'raw/dealer-service.json').read_text())
preview=json.loads((root/'change-preview.json').read_text())
source_ids=[x['id'] for x in snapshot['dealers']]
rows=preview['rows']
assert source_ids==preview['target_ids']==[x['id'] for x in rows]
assert len(set(source_ids))==len(source_ids)==4
assert preview['excluded_ids']==[]
assert sum(x['candidate_action']=='unchanged' for x in rows)==1
assert sum(x['candidate_action']=='grant-existing-feature' for x in rows)==3
for before,row in zip(snapshot['dealers'],rows):
    assert row['lifecycle_before']==row['lifecycle_expected_after']==before['state']
    assert row['feature_enabled_before']==before['feature_enabled']
    assert row['feature_enabled_expected_after'] is True
assert preview['submitted'] is False and preview['execution_granted'] is False
execution=json.loads((root/'execution-status.json').read_text())
assert execution['status']=='not_attempted' and execution['api_calls']==[] and execution['results']==[]
dump(root/'raw/preview-inspection.json',{'command':'python3 run_checks.py (task-local host: independently compare source inventory and every preview row)','status':'PREPARATION_CONSISTENT_WITH_SIMULATED_INPUT_ONLY','source_ids':source_ids,'targets':len(rows),'unchanged':1,'proposed_new_grants':3,'excluded':0,'lifecycle_expected_unchanged':True,'simulation_mutated':False,'production_proof':'NOT_VERIFIED','execution_granted':False,'limits':'Checks projection integrity only; no runtime, actual service API schema, actual eligibility policy, independent approval or real outcome is verified.'})
assert run(['git','rev-parse','HEAD'],'raw/check-baseline-after.txt').stdout.strip()==baseline
assert r.returncode==0 and check['status']=='PASS_STATIC_ONLY'
print('Saved exact workflow hashes, raw command outputs and simulation-only inspection results.')
