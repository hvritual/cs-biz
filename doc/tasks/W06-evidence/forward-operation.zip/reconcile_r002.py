from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil
root=Path('/workspace/scratch/0fc9dd84ab02/w06-forward-operation')
archive=root/'revisions/r001'
assert not archive.exists()
archive.mkdir(parents=True)
for p in list(root.iterdir()):
    if p.name=='revisions':continue
    if p.is_dir():shutil.copytree(p,archive/p.name)
    elif p.is_file():shutil.copyfile(p,archive/p.name)

def load(name):return json.loads((root/name).read_text())
def dump(name,x):(root/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def ref(name):return {'path':name,'sha256':hashlib.sha256((root/name).read_bytes()).hexdigest()}
def digest(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
goal=load('goal.json');assessment=load('assessment.json');plan=load('operation.json');preview=load('change-preview.json')
old_basis=assessment['basis_sha256'];old_plan_ref=ref('operation.json');old_preview_ref=ref('change-preview.json');old_id=plan['operation_id']
assert goal['revision']=='r001'
goal['revision']='r002'
new_basis=digest({k:v for k,v in goal.items() if k not in ('records','budget')})
environment='UNBOUND production target (organization/environment not supplied); isolated simulated snapshot is preparation evidence only; no execution authority'
for c in assessment['criteria']:c['environment']=environment
assessment['basis_sha256']=new_basis
dump('assessment.json',assessment)
new_id=old_id.replace('-r001-','-r002-')
plan['basis_sha256']=new_basis;plan['assessment_sha256']=ref('assessment.json')['sha256'];plan['environment']=environment;plan['operation_id']=new_id
dump('operation.json',plan)
goal['records']={'assessment':ref('assessment.json'),'operation':ref('operation.json')}
dump('goal.json',goal)
preview['operation_id']=new_id
# Keep observed input environment explicit in the preview; it is not an executed plan.
dump('change-preview.json',preview)
decisions=load('human-decisions.json');decisions['basis_sha256']=new_basis;decisions['assessment_ref']=ref('assessment.json');dump('human-decisions.json',decisions)
execution=load('execution-status.json');execution['operation_id']=new_id;execution['plan_ref']=ref('operation.json');dump('execution-status.json',execution)
report=(root/'handoff.md').read_text()
report=report.replace(old_id,new_id).replace(old_plan_ref['sha256'],ref('operation.json')['sha256']).replace(old_preview_ref['sha256'],ref('change-preview.json')['sha256']).replace('保留此 r001','保留已有修订记录')
report+='\n修订记录：r001 首次静态检查因验收环境文字与操作环境文字不一致失败，原版及失败原始输出完整保留在 revisions/r001。r002 仅统一环境身份为“生产目标未绑定，模拟快照仅准备证据”，重新绑定哈希与未执行候选标识；没有更改分母、目标、验收动作、观察要求、政策缺口或审批状态。详见 raw/revision-reconciliation.json。\n'
(root/'handoff.md').write_text(report,encoding='utf-8')
dump('raw/revision-reconciliation.json',{'observed_at':datetime.now(timezone.utc).isoformat(),'from_revision':'r001','to_revision':'r002','old_basis_sha256':old_basis,'new_basis_sha256':new_basis,'cause':'Actual static checker rejected operation acceptance environment mismatch. Original output retained in revisions/r001/raw/check-goal-output.json (exit 2); host assertion also failed.','correction':'Use a single explicit unbound-production environment identifier across all acceptance criteria and the unexecuted draft operation. Simulated observations remain simulated and no criterion outcome is claimed.','old_operation_ref':old_plan_ref,'new_operation_ref':ref('operation.json'),'old_operation_id':old_id,'new_operation_id':new_id,'id_change_rationale':'Different unexecuted preparation revision; no real service operation was attempted or replayed, and no actual service idempotency identity exists.','reused_evidence':'Exact raw source and inventory bytes, same four targets, no exclusions; policy/resource decisions remain unanswered.','invalidated_evidence':'r001 bindings and static validation result do not establish r002 validity; rerun required.','promises_changed':False,'human_approval_changed':False,'execution_attempted':False})
print(json.dumps({'revision':'r002','operation_id':new_id,'environment':environment,'goal_ref':ref('goal.json'),'operation_ref':ref('operation.json'),'original_failure_preserved':str(archive/'raw/check-goal-output.json')},ensure_ascii=False,indent=2))
