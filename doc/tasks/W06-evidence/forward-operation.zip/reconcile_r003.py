from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,shutil
root=Path('/workspace/scratch/0fc9dd84ab02/w06-forward-operation');repo=Path('/workspace/scratch/0fc9dd84ab02/cs-biz')
def load(n):return json.loads((root/n).read_text())
def dump(n,x):(root/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(n):return {'path':n,'sha256':sha(root/n)}
def digest(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
g=load('goal.json');assert g['revision']=='r002'
current=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
comparison=[]
for source in g['sources']:
    if source['channel']!='local-repository':continue
    actual=sha(Path(source['locator']))
    comparison.append({'id':source['id'],'source':source['locator'],'original_sha256':source['artifact_ref']['sha256'],'current_sha256':actual,'byte_identical':actual==source['artifact_ref']['sha256']})
    assert actual==source['artifact_ref']['sha256'],'Relevant source drift: re-discovery needed, not baseline-only reconciliation'
assert sha(repo/'.agents/skills/intent-to-outcome-closure/scripts/check_goal.py')==sha(root/'raw/check_goal.py')
archive=root/'revisions/r002';assert not archive.exists();archive.mkdir(parents=True)
for p in list(root.iterdir()):
    if p.name=='revisions':continue
    if p.is_dir():shutil.copytree(p,archive/p.name)
    elif p.is_file():shutil.copyfile(p,archive/p.name)
a=load('assessment.json');p=load('operation.json');v=load('change-preview.json')
old_head=g['baseline_sha'];old_basis=a['basis_sha256'];old_id=p['operation_id'];old_plan_ref=ref('operation.json');old_preview_ref=ref('change-preview.json')
g['revision']='r003';g['baseline_sha']=current
for source in g['sources']:
    if source['channel']=='local-repository':source['version']+='; exact bytes independently revalidated at current local HEAD '+current
basis=digest({k:x for k,x in g.items() if k not in ('records','budget')})
a['basis_sha256']=basis;dump('assessment.json',a)
new_id=old_id.replace('-r002-','-r003-');p['basis_sha256']=basis;p['assessment_sha256']=ref('assessment.json')['sha256'];p['operation_id']=new_id;dump('operation.json',p)
g['records']={'assessment':ref('assessment.json'),'operation':ref('operation.json')};dump('goal.json',g)
v['operation_id']=new_id;dump('change-preview.json',v)
h=load('human-decisions.json');h['basis_sha256']=basis;h['assessment_ref']=ref('assessment.json');dump('human-decisions.json',h)
e=load('execution-status.json');e['operation_id']=new_id;e['plan_ref']=ref('operation.json');dump('execution-status.json',e)
report=(root/'handoff.md').read_text().replace(old_id,new_id).replace(old_plan_ref['sha256'],ref('operation.json')['sha256']).replace(old_preview_ref['sha256'],ref('change-preview.json')['sha256']).replace('本地仓库 HEAD：'+old_head,'本地仓库 HEAD：'+current)
report+='\nr003 基线对账：第二次检查因 HEAD 从 '+old_head+' 变为 '+current+' 失败；r002 及 exit=2 原始输出保留在 revisions/r002。独立逐项比较本任务所有相关源文件，字节均未变；仅更新本地基线与复核出处，保留相同目标、政策缺口、验收、未授权状态，重新执行静态检查。该复核不是远程 main/生产核验。详见 raw/baseline-reconciliation-r003.json。\n'
(root/'handoff.md').write_text(report,encoding='utf-8')
dump('raw/baseline-reconciliation-r003.json',{'observed_at':datetime.now(timezone.utc).isoformat(),'command':'python3 reconcile_r003.py: git rev-parse HEAD and sha256 of every relevant goal local-repository source','from_revision':'r002','to_revision':'r003','old_local_head':old_head,'new_local_head':current,'source_comparisons':comparison,'checker_sha256':sha(root/'raw/check_goal.py'),'old_basis_sha256':old_basis,'new_basis_sha256':basis,'reuse_rationale':'All selected fact/rule source bytes and isolated service input are unchanged. No current GitHub/main/production claim depends on baseline advancement. Reuse is limited to the same unexecuted preparation and unanswered decisions; no authentic approval or runtime is inferred.','old_operation_id':old_id,'new_operation_id':new_id,'operation_id_change_rationale':'Unexecuted preparation revision only; no real service attempt or service idempotency identity exists.','original_failure':'revisions/r002/raw/check-goal-output-attempt002.json; exit 2','promises_changed':False,'executed':False,'authentic_approval':'NOT_VERIFIED','runtime':'NOT_VERIFIED','execution_granted':False,'counterevidence':'Local baseline may drift again. Actual environment/organization, authoritative inventory, lifecycle policy and real authorization remain absent.'})
script=(root/'validate_r002.py').read_text().replace('attempt002','attempt003').replace('validate_r002.py','validate_r003.py')
(root/'validate_r003.py').write_text(script,encoding='utf-8')
print(json.dumps({'revision':'r003','local_head':current,'operation_id':new_id,'original_failures_preserved':['revisions/r001/raw/check-goal-output.json','revisions/r002/raw/check-goal-output-attempt002.json']},ensure_ascii=False,indent=2))
