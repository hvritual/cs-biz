目前仅完成隔离模拟清单的审核准备，生产开通未执行，生产生效未验证。

目标：给目标组织全部经销商开通已有 marketing-campaign 功能；先准备，交请求人审核，再由另行获权的操作方生效并回读。当前可接受的交付边界仅是模拟输入候选及资源/政策决定包。

来源与边界

- 模拟清单原文 observed_at：2026-10-16T08:20:00+00:00；pages_complete=true 是输入声明。4 个唯一 ID 全部保留，不能代表真实组织的生产全量。
- 本地候选 HEAD（不是 GitHub main）：aec53bddd7818e8a554c01902342593f894c4dc9。相关当前工作树文档以原字节保存并逐一哈希；路线是导航，不是生产证明。无源码修改、部署或外部服务操作。
- 输入声明已有 published feature、POST /admin/features/grants、GET /admin/features/grants 和幂等支持；未提供真实 host、请求 schema、身份、生命周期规则、审计/补偿语义。未伪造可执行请求。
- 功能开通不自动赋予 IAM 权限；不得由菜单或模拟状态推导后端有效授权。

候选预览（只为预期，未写入）

| ID | 当前生命周期 | 当前功能 | 候选变化 | 预期生命周期 |
| --- | --- | --- | --- | --- |
| d01 | active | 已开 | 保留，不新增 | active |
| d02 | active | 未开 | 拟开通 | active |
| d03 | suspended | 未开 | 拟开通；先核对服务政策 | suspended |
| d04 | archived | 未开 | 拟开通；先核对服务政策 | archived |

分母 4，已开保留 1，拟新增 3，排除 0。没有把“全部”默改成“活跃”；d03/d04 的可授予性及有效权益语义尚未确认。若服务规则不允许某项，先提交精确 ID、原因及范围修订给请求人，不自行剔除。active-only 方案仅是未选的范围修订选项。

审核候选

- preparation operation ID：prep-marketing-campaign-all-dealers-r003-7123d72a0159。这是本地准备标识，不是服务接受的执行或幂等回执。
- operation.json SHA256：e19133802623855450cccdd5f24a68fb2c0573d2bf5bb68a537e7b0ba0ee89dc。
- change-preview.json SHA256：c3c8335052024571e83e38b5940c5ed2b4f07a839f3f6a6e3c42ee8b00da7179。
- 目标与预期、原始清单、未选方案和 Human 决定均已落档；execution-status.json 明确无调用、无结果。没有审批响应或执行记录冒充事实。

当前验收状态

| 标准 | 当前证据/状态 |
| --- | --- |
| AC-INVENTORY 全量分母 | 模拟文件内 4/4、唯一性和分区已核对；生产 BLOCKED，真实枚举不可用 |
| AC-ENABLE 实际开通 | UNPROVEN / 当前 OUTSIDE_AUTHORITY；没有生产 grant 或有效权益回读 |
| AC-REVIEW 先审后生效 | 该模拟候选已可审；真实生产审核 BLOCKED，authentic_approval=NOT_VERIFIED |
| AC-RECOVERY 执行/恢复 | 准备说明已完成；真实接口恢复合同和运行证明 BLOCKED，runtime=NOT_VERIFIED |

工作图与必要性

| 节点 | 分类 / 对应标准 | 状态 / 依赖 |
| --- | --- | --- |
| W1 读取现有能力和全量快照 | 派生 / AC-INVENTORY、AC-ENABLE | 已交付，限模拟 |
| W2 全量预览和审核资料 | 明示 / AC-REVIEW | 已交付，限当前候选 |
| W3 获取生命周期/授予政策 | 派生 / AC-ENABLE | BLOCKED；D-LIFECYCLE-POLICY |
| W4 真实环境和最小只读资源 | 派生 / AC-INVENTORY、AC-ENABLE | BLOCKED；D-PRODUCTION-RESOURCE |
| W5 当前生产候选与真实审核 | 明示 / AC-REVIEW | 待 W3/W4；不以此模拟包替代 |
| W6 另行获权的既有 API 开通 | 明示 / AC-ENABLE | OUTSIDE_AUTHORITY；待 W5 和真实执行权限 |
| W7 逐目标回读及异常恢复 | 派生 / AC-ENABLE、AC-RECOVERY | 待真实操作；未知结果先按原操作 ID 回读 |

拟请 Human 提供的具体输入（未发送外部消息）

1. 服务 Owner 提供既有政策/合同：suspended/archived 经销商是否可授予、授予是否会改变生命周期/IAM、有效权益如何核验。推荐提供原有版本化规则；替代为暂停此生产分支。事实、缺口、选项、影响、Owner、请求动作均见 human-decisions.json。
2. 请求人/服务管理员提供目标组织及实际环境，并优先配置最小只读访问与真实全量枚举、接口/幂等/审计/补偿合同。也可先提供有来源、时间及全分页证明的权威导出以准备临时审核；该方案仍需后续 live preflight/readback。替代为暂缓生产。该资源输入不构成写入批准。

单一下一步：由请求人/服务 Owner 补齐上述政策和真实只读资源；随后复核当前全量范围，保留已有修订记录，生成绑定真实环境的新生产候选，再通知请求人作精确版本的生效审核。现在不请求批准一个未经生产核验的批次。

恢复要求：未知结果保留真实服务 operation/idempotency ID 并先回读；不盲重试，不假定批量原子性，不虚构撤销接口；补偿需既有服务支持和真实授权，且不能撤掉原已存在的 d01 权益。

本次没有真实业务成果可验收；静态检查只证明本地记录绑定，不证明真实审批、功能存在于生产或生产生效。请求人在审阅时可同时校准是否遗漏必需工作、越权、证据不足或存在过强完成表述。

修订记录：r001 首次静态检查因验收环境文字与操作环境文字不一致失败，原版及失败原始输出完整保留在 revisions/r001。r002 仅统一环境身份为“生产目标未绑定，模拟快照仅准备证据”，重新绑定哈希与未执行候选标识；没有更改分母、目标、验收动作、观察要求、政策缺口或审批状态。详见 raw/revision-reconciliation.json。

r003 基线对账：第二次检查因 HEAD 从 4d5dd75500de601cbadd41ade18c2459c72c23b5 变为 aec53bddd7818e8a554c01902342593f894c4dc9 失败；r002 及 exit=2 原始输出保留在 revisions/r002。独立逐项比较本任务所有相关源文件，字节均未变；仅更新本地基线与复核出处，保留相同目标、政策缺口、验收、未授权状态，重新执行静态检查。该复核不是远程 main/生产核验。详见 raw/baseline-reconciliation-r003.json。

最终本地检查：r003 返回 PASS_STATIC_ONLY，next_action=HUMAN_DECISION；待 D-LIFECYCLE-POLICY、D-PRODUCTION-RESOURCE，缺少 production-service。authentic_approval/runtime 均 NOT_VERIFIED，execution_granted=false。实际命令、exit=0 原始输出及精确 checker 哈希见 raw/check-commands-attempt003.json、raw/check-goal-output-attempt003.json、raw/workflow-source-hashes.json。

基线出处补充：aec53bddd7818e8a554c01902342593f894c4dc9 是本次本地候选提交，不能称为 canonical main。父任务报告最后独立观察的 GitHub main 为 4d5dd75500de601cbadd41ade18c2459c72c23b5；本 Agent 未重新读取 GitHub。此信息仅用于来源分类，不作为生产或审批证据，见 raw/provenance-addendum.json。
