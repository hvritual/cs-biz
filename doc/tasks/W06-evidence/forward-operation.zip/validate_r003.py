from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,importlib.util
sys.dont_write_bytecode=True
root=Path('/workspace/scratch/0fc9dd84ab02/w06-forward-operation');repo=Path('/workspace/scratch/0fc9dd84ab02/cs-biz');checker=repo/'.agents/skills/intent-to-outcome-closure/scripts/check_goal.py'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(name,x):(root/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert sha(checker)==sha(root/'raw/check_goal.py'),'Checker drift; stop and preserve original checker snapshot'
commands=[]
def run(args,name):
    started=datetime.now(timezone.utc).isoformat();r=subprocess.run(args,cwd=repo,capture_output=True,text=True)
    (root/name).write_text(r.stdout,encoding='utf-8');(root/(name+'.stderr')).write_text(r.stderr,encoding='utf-8')
    commands.append({'argv':args,'cwd':str(repo),'started_at':started,'completed_at':datetime.now(timezone.utc).isoformat(),'exit_code':r.returncode,'stdout_ref':{'path':name,'sha256':sha(root/name)},'stderr_ref':{'path':name+'.stderr','sha256':sha(root/(name+'.stderr'))},'checker_sha256':sha(checker) if str(checker) in args else None})
    dump('raw/check-commands-attempt003.json',commands);return r
baseline=run(['git','rev-parse','HEAD'],'raw/attempt003-baseline-before.txt').stdout.strip()
r=run(['python3',str(checker),'--task',str(root),'--live-baseline',baseline],'raw/check-goal-output-attempt003.json')
assert sha(checker)==sha(root/'raw/check_goal.py'),'Checker changed during command; stop'
print(r.stdout)
if r.returncode:raise SystemExit(r.returncode)
spec=importlib.util.spec_from_file_location('snapshotted_goal_checker',root/'raw/check_goal.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
g=module.load(root/'goal.json');a=module.load(root/'assessment.json');p=module.operation(root,g,a)
dump('raw/operation-binding-check-attempt003.json',{'status':'PASS_STATIC_ONLY','command':'python3 validate_r003.py: module.operation(root, goal, assessment), exact raw/check_goal.py','checker_sha256':sha(checker),'operation_id':p['operation_id'],'environment':p['environment'],'targets':p['targets'],'exclusions':p['exclusions'],'authentic_approval':'NOT_VERIFIED','runtime':'NOT_VERIFIED','execution_granted':False})
s=module.load(root/'raw/dealer-service.json');v=module.load(root/'change-preview.json');e=module.load(root/'execution-status.json')
assert s['pages_complete'] is True
assert [d['id'] for d in s['dealers']]==p['targets']==v['target_ids']==[x['id'] for x in v['rows']]
assert len(set(p['targets']))==len(p['targets'])==4 and p['exclusions']==v['excluded_ids']==[]
assert sum(x['candidate_action']=='unchanged' for x in v['rows'])==1
assert sum(x['candidate_action']=='grant-existing-feature' for x in v['rows'])==3
for d,row in zip(s['dealers'],v['rows']):
    assert row['feature_enabled_before']==d['feature_enabled']
    assert row['lifecycle_before']==row['lifecycle_expected_after']==d['state']
    assert row['feature_enabled_expected_after'] is True
assert v['execution_granted'] is False and v['submitted'] is False
assert e['status']=='not_attempted' and e['api_calls']==e['results']==[]
assert e['plan_ref']['sha256']==sha(root/'operation.json')
check={'status':'PREPARATION_CONSISTENT_WITH_SIMULATED_INPUT_ONLY','observed_at':datetime.now(timezone.utc).isoformat(),'command':'python3 validate_r003.py: source-derived denominator, each before-state, expected lifecycle preservation, target partition and no-execution inspection','targets':4,'unchanged':1,'proposed_new_grants':3,'exclusions':0,'source_ref':{'path':'raw/dealer-service.json','sha256':sha(root/'raw/dealer-service.json')},'preview_ref':{'path':'change-preview.json','sha256':sha(root/'change-preview.json')},'approval':'NOT_VERIFIED','runtime':'NOT_VERIFIED','execution_granted':False,'limits':'A static projection inspection, not service execution, actual grant eligibility, Human acceptance, production inventory or production proof.'}
dump('raw/preview-inspection-attempt003.json',check)
assert run(['git','rev-parse','HEAD'],'raw/attempt003-baseline-after.txt').stdout.strip()==baseline
assert sha(checker)==sha(root/'raw/check_goal.py')
print(json.dumps(check,ensure_ascii=False,indent=2))
