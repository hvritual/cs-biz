import importlib.util,json,shutil,subprocess
from pathlib import Path
OUT=Path('/workspace/scratch/0fc9dd84ab02/w06-independent-review')
ROOT=Path('/workspace/scratch/0fc9dd84ab02/cs-biz')
source=OUT/'check_goal-after-repair.py'
spec=importlib.util.spec_from_file_location('after_repair',source);api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)
def read(task,name):return json.loads((task/name).read_text())
def write(task,name,value):
 p=task/name;p.write_text(json.dumps(value,indent=2)+'\n');return {'path':name,'sha256':api.digest(p.read_bytes())}
def copy_case(name,original):
 p=OUT/name
 if p.exists():shutil.rmtree(p)
 shutil.copytree(OUT/original,p);return p
def mutate_execution(task,fn):
 goal=read(task,'goal.json');run=read(task,'execution.json');fn(run)
 goal['records']['execution']=write(task,'execution.json',run);write(task,'goal.json',goal)
def cli(task,live=None):
 args=['python3',str(source),'--task',str(task)]
 if live:args+=['--live-baseline',live]
 p=subprocess.run(args,capture_output=True,text=True)
 assert not p.stderr,p.stderr
 return {'returncode':p.returncode,'result':json.loads(p.stdout)}
results={}
t=copy_case('failed-incomplete-coverage','failed-with-unknown-targets')
mutate_execution(t,lambda r:r.update(results=r['results'][:1]))
results['failed-incomplete-coverage']=cli(t)
assert results['failed-incomplete-coverage']['result']['next_action']=='READBACK_OPERATION'

t=copy_case('failed-known-all-targets','failed-with-unknown-targets')
mutate_execution(t,lambda r:[x.update(status='failed') for x in r['results']])
results['failed-known-all-targets']=cli(t)
assert results['failed-known-all-targets']['result']['next_action']=='REPAIR_OPERATION'

t=copy_case('unknown-exhausted-budget','failed-with-unknown-targets')
g=read(t,'goal.json');g['budget']['attempts_without_progress']=2;write(t,'goal.json',g)
results['unknown-exhausted-budget']=cli(t)
assert results['unknown-exhausted-budget']['result']['next_action']=='READBACK_OPERATION'

t=copy_case('drift-mismatched-id','unknown-after-feedback')
mutate_execution(t,lambda r:r.update(operation_id='wrong-operation'))
results['drift-mismatched-id']=cli(t)
assert results['drift-mismatched-id']['returncode']==2 and results['drift-mismatched-id']['result']['recovery_hint'] is None

t=copy_case('drift-corrupt-plan-bytes','unknown-after-feedback')
(t/'operation.json').write_text((t/'operation.json').read_text()+' ')
results['drift-corrupt-plan-bytes']=cli(t)
assert results['drift-corrupt-plan-bytes']['returncode']==2 and results['drift-corrupt-plan-bytes']['result']['recovery_hint'] is None

t=OUT/'software-current-route'
if t.exists():shutil.rmtree(t)
shutil.copytree(ROOT/'.agents/skills/intent-to-outcome-closure/examples/saas',t)
results['software-current-route']=cli(t)
assert results['software-current-route']['result']['next_action']=='ROUTE_SOFTWARE'
assert results['software-current-route']['result']['resources']==['../sdlc-workflow/SKILL.md']
for name,res in results.items():
 assert res['result']['execution_granted'] is False
(OUT/'repair-controls-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({name:{'exit':r['returncode'],'action':r['result'].get('next_action'),'hint':r['result'].get('recovery_hint')} for name,r in results.items()},indent=2))
