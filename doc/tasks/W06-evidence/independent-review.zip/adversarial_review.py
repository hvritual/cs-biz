import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/workspace/scratch/0fc9dd84ab02/cs-biz')
OUT = Path('/workspace/scratch/0fc9dd84ab02/w06-independent-review')
PACKAGE = ROOT / '.agents/skills/intent-to-outcome-closure'
spec = importlib.util.spec_from_file_location('reviewed_goal_checker', PACKAGE / 'scripts/check_goal.py')
api = importlib.util.module_from_spec(spec)
spec.loader.exec_module(api)

def read(task, name): return json.loads((task / name).read_text())
def write(task, name, data):
    p = task / name
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    return {'path': name, 'sha256': api.digest(p.read_bytes())}
def fixture(name):
    task = OUT / name
    if task.exists(): shutil.rmtree(task)
    shutil.copytree(PACKAGE / 'examples/operation', task)
    return task

def execution(task, status, target_status):
    goal = read(task, 'goal.json'); plan = read(task, 'operation.json')
    evidence = write(task, 'asserted-evidence.json', {'synthetic': True, 'note': 'No actual authority or target observation.'})
    run = {'basis_sha256': api.basis(goal), 'plan_sha256': goal['records']['operation']['sha256'],
           'operation_id': plan['operation_id'], 'environment': plan['environment'],
           'authority_record_ref': evidence, 'status': status,
           'results': [{'id': i, 'status': target_status, 'evidence_ref': evidence} for i in plan['targets']],
           'proofs': []}
    goal['records']['execution'] = write(task, 'execution.json', run)
    write(task, 'goal.json', goal)

def check(task, live=None):
    args = ['python3', str(PACKAGE / 'scripts/check_goal.py'), '--task', str(task)]
    if live: args += ['--live-baseline', live]
    run = subprocess.run(args, capture_output=True, text=True)
    return {'returncode': run.returncode, 'stdout': run.stdout, 'stderr': run.stderr}

results = {}
task = fixture('failed-with-unknown-targets')
execution(task, 'failed', 'unknown')
results['failed-with-unknown-targets'] = check(task)

task = fixture('unknown-after-feedback')
execution(task, 'unknown', 'unknown')
goal = read(task, 'goal.json')
goal['feedback_refs'].append(write(task, 'new-feedback.json', {'text': 'Keep the in-flight operation paused until its effects are read back; revise the next plan.'}))
goal['revision'] = 'r002'
write(task, 'goal.json', goal)
results['unknown-after-feedback'] = check(task, goal['baseline_sha'])

task = fixture('unknown-after-main-drift')
execution(task, 'unknown', 'unknown')
results['unknown-after-main-drift'] = check(task, 'b' * 40)

task = fixture('malformed-stage-json')
goal = read(task, 'goal.json')
goal['records']['assessment'] = write(task, 'assessment.json', [])
write(task, 'goal.json', goal)
results['malformed-stage-json'] = check(task)

(OUT / 'adversarial-results.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
